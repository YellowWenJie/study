<template>
	<view class="g-ft">
		<view class="g-ft1">
			<view class="i-contact">
				<view class="img-qcode">
					<image src="../../static/img/common/ft-code-app.jpg" mode=""></image>
					<text>APP下载</text>
				</view>
				<view class="img-qcode">
					<image src="../../static/img/common/ft-code-wx.jpg" mode=""></image>
					<text>关注牛汽配</text>
				</view>
				<view class="u-tel">
					<view class="tit">
						服务热线:
					</view>
					<view class="num">
						400-8260-004
					</view>
				</view>
			</view>
		</view>
		<view class="g-ft2">
			<view class="gongan">
				<view>
					<image src="../../static/img/common/icon-gongan.png" mode=""></image>
				</view>
				<view class="p">
					浙公网安备 33010502003702号 
				</view>
			</view>
			<view class="u-text">
				浙ICP备16027418号-2 
			</view>
			<view class="u-text">
				© 2015-2018 浙江特浦科技有限公司
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'iFooter',
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">
@import './footer.scss'
</style>
