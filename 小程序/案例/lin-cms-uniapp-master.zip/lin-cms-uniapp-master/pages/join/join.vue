<template>
	<view class="g-box">
		招商加盟
	</view>
</template>

<script>

	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">
@import './join.scss'
</style>
