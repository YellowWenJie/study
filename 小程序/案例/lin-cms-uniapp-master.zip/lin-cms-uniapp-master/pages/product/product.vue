<template>
	<view class="g-box">
		<view class="g-hd">
			<view class="m-video">
				<video 
				src="https://niuqipei-video.oss-cn-hangzhou.aliyuncs.com/xuanchuan700.mp4" 
				class="u-video"
				></video>
			</view>
			<!-- 			
				<view class="m-banner">
					<image src="../../static/img/join/ban-join.jpg" mode=""></image>
				</view>
			-->
		</view>
		<view class="g-bd">
			
		</view>
		
		<!-- 底部区域 -->
		<!-- <i-footer></i-footer> -->
	</view>
</template>

<script>
	export default {
		
	}
</script>

<style lang="scss" scoped>
 @import './product.scss'
</style>

